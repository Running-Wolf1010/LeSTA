clc
currentFolder = pwd;
addpath(genpath(currentFolder))

[lb,ub,fobj] = Get_Functions_details('F13');

n = 50; % ά��
lb = 0*ones(1,n);
ub = 2*n*ones(1,n);
% MaxFEs = 3e3 * n * log2(n); %
MaxFEs = n*1e4; %
s = 2:1:n+1; 

funfcn = @(x) fobj(x-s);

Range = [lb;ub];
tic
[Best,fBest,history] = LeSTA(funfcn,n,Range,MaxFEs);
toc
fBest
semilogy(history)
legend('LeSTA')

