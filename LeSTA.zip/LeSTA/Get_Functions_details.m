function [lb,ub,fobj] = Get_Functions_details(F)

switch F
    case 'F1'
        fobj = @F1;
        lb=-100;
        ub=100;
        disp('Sphere');
        
    case 'F2'
        fobj = @F2;
        lb=-10;
        ub=10;
        disp('Schwefel 2.22');
        
    case 'F3'
        fobj = @F3;
        lb=-100;
        ub=100;
        disp('Schewefel 1.2');
        
    case 'F4'
        fobj = @F4;
        lb=-30;
        ub=30;
        disp('Rosenbrock');
        
    case 'F5'
        fobj = @F5;
        lb=0;
        ub=10;
        disp('Schwefel 2.4');
    
    case 'F6'
        fobj = @F6;
        lb=-100;
        ub=100;
        disp('Elliptic');
        
    case 'F7'
        fobj = @F7;
        lb=-100;
        ub=100;
        disp('Tablet');
        
    case 'F8'
        fobj = @F8;
        lb=-5;
        ub=10;
        disp('Zakharov');
        
    case 'F9'
        fobj = @F9;
        lb=-50;
        ub=50;
        disp('Penalized 1');
        
    case 'F10'
        fobj = @F10;
        lb=-50;
        ub=50;
        disp('Penalized 2');  
        
    case 'F11'
        fobj = @F11;
        lb=-32;
        ub=32;
        disp('Ackley');    
        
    case 'F12'
        fobj = @F12;
        lb=-600;
        ub=600;
        disp('Griewank');
        
    case 'F13'
        fobj = @F13;
        lb=-5.12;
        ub=5.12;
        disp('Rastrigin');
  
    case 'F14'
        fobj = @F14;
        lb=-10;
        ub=10;
        disp('Levy_Montalo1');
        
    case 'F15'
        fobj = @F15;
        lb=-5;
        ub=5;
        disp('Levy_Montalo2');
end

end

function o = F1(x)
o=sum(x.^2,2);
end

function o = F2(x)
o=sum(abs(x),2)+prod(abs(x),2);
end

function o = F3(x)
dim=size(x,2);
o=0;
for i=1:dim
o=o+sum(x(:,1:i),2).^2;
end
end

function o = F4(x)
o=sum(100*(x(:,2:end)-(x(:,1:end-1).^2)).^2+(x(:,1:end-1)-1).^2,2);
end

function o = F5(x)
o = sum((x-1).^2 + (x(:,1)-x.^2).^2,2); 
end

function o = F6(x)
[~, dim] = size(x);
o = sum((10^6).^(((1:dim)-1)./(dim-1)).*x.^2,2);
end

function fit=F7(L)
[~, dim] = size(L);
fit = 10^6*L(:,1).^2 + sum(L(:,2:dim).^6,2);
end

function o = F8(x)
[~,n] = size(x);
o = sum(x.^2,2) + (sum(0.5*(1:n).*x,2)).^2 + (sum(0.5*(1:n).*x,2)).^4;
end

function o = F9(x)
dim=size(x,2);
o=(pi/dim)*(10*((sin(pi*(1+(x(:,1)+1)./4))).^2)+sum((((x(:,1:dim-1)+1)./4).^2).*...
(1+10.*((sin(pi.*(1+(x(:,2:dim)+1)./4)))).^2),2)+((x(:,dim)+1)/4).^2)+sum(Ufun(x,10,100,4),2);
end

function o = F10(x)
dim=size(x,2);
o=.1*((sin(3*pi.*x(:,1))).^2+sum((x(:,1:dim-1)-1).^2.*(1+(sin(3.*pi.*x(:,2:dim))).^2),2)+...
((x(:,dim)-1).^2).*(1+(sin(2.*pi.*x(:,dim))).^2))+sum(Ufun(x,5,100,4),2);
end

function o=Ufun(x,a,k,m)
o=k.*((x-a).^m).*(x>a)+k.*((-x-a).^m).*(x<(-a));
end

function o = F11(x)
dim=size(x,2);
o=-20*exp(-0.2*sqrt(1/dim*sum(x.^2,2)))-exp(1/dim*sum(cos(2*pi.*x),2))+20+exp(1);
end

function o = F12(x)
dim=size(x,2);
o=sum(x.^2,2)/4000-prod(cos(x./sqrt([1:dim])),2)+1;
end

function o = F13(x)
dim=size(x,2);
o=sum(x.^2-10*cos(2*pi.*x),2)+10*dim;
end

function o = F14(x)
[~, Dim] = size(x);
o=pi/Dim*(10*(sin(pi*(1+0.25.*(x(:,1)+1)))).^2 + sum((1+0.25.*(x(:,1:Dim-1)+1)-1).^2.*(1+10*(sin(pi*(1+0.25.*(x(:,2:Dim)+1)))).^2),2)+(1+0.25.*(x(:,Dim)+1)-1).^2);
end

function o = F15(x)
[~, Dim] = size(x);
o=0.1*((sin(3*pi.*x(1))).^2+sum((x(:,1:Dim-1)-1).^2.*(1+(sin(3*pi.*x(:,2:Dim))).^2)+(x(Dim)-1).^2.*(1+(sin(2*pi.*x(Dim))).^2),2));
end

